<!DOCTYPE html>
<html>
	<head>
		<title> My first game in PHP </title>
	</head>
	<body>
		<header>
			<link rel="stylesheet" href="Style.css" type="text/css"/>
			<?php
			require_once 'MyLib.php';
			print "<h1>Welcome to the Guess Game!</h1>";
			checkVictory();
			?>
		</header>

		<form action="Exercise1.php" method="post">
			<?php
			if (isset($_POST["level"]) == FALSE || $_POST["choose"]=='Restart') {
				print "Easy <input type='radio' name='level' value='Easy'/>";
				print "Medium <input type='radio' name='level' value='Medium'/>";
				print "Hard <input type='radio' name='level' value='Hard'/>";
				print "<br>";
			} else {
				if ($_POST['level'] == 'Easy') {
					print "Easy <input type='radio' name='level' value='Easy' checked/>";
					print "Medium <input type='radio' name='level' value='Medium' disabled/>";
					print "Hard <input type='radio' name='level' value='Hard' disabled/>";
					print "<br>";
				} else if ($_POST['level'] == 'Medium') {
					print "Easy <input type='radio' name='level' value='Easy'disabled/>";
					print "Medium <input type='radio' name='level' value='Medium' checked/>";
					print "Hard <input type='radio' name='level' value='Hard'disabled/>";
					print "<br>";
				} else if ($_POST['level'] == 'Hard') {
					print "Easy <input type='radio' name='level' value='Easy'disabled/>";
					print "Medium <input type='radio' name='level' value='Medium' disabled/>";
					print "Hard <input type='radio' name='level' value='Hard' checked/>";
					print "<br>";
				}
			}
			?>
			Guess number:
			<input type="number" name="numberTyped" />
			<?php
			if (isset($_POST["result"]) && $_POST["result"] == 'w' || $_POST["result"] == 'g') {
				print "<input type='submit' name='choose' value='Try' disabled/>";
			} else if (isset($_POST["result"]) && $_POST["result"] == 'c') {
				print "<input type='submit' name='choose' value='Try'/>";
			}
			?>
			<input type="submit" name="choose" value="Restart"/>
		</form>
		<a href="Info.html">
		<button>
			How to play!
		</button> </a>
		<footer>
			Copyright &#169 Flavio Colonna Romano
		</footer>
		<script></script>
	</body>
</html>