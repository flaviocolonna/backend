<?php
function guessFirstNumber() {
	if ($_POST["level"] == 'Easy') {
		print "<h3><strong>You have choosed Easy! Guess a number between 0 and 20</strong></h3>";
		$number = rand(0, 20);
		$_POST["guessNumber"] = $number;
		setcookie("guessNumber", $number, time() + 3600 * 24);
	}
	if ($_POST["level"] == 'Medium') {
		print "<h3><strong>You have choosed Medium! Guess a number between 0 and 30</strong></h3>";
		$number = rand(0, 30);
		$_POST["guessNumber"] = $number;
		setcookie("guessNumber", $number, time() + 3600 * 24);
	}
	if ($_POST["level"] == 'Hard') {
		print "<h3><strong>You have choosed Hard! Guess a number between 0 and 40</strong></h3>";
		$number = rand(0, 40);
		$_POST["guessNumber"] = $number;
		setcookie("guessNumber", $number, time() + 3600 * 24);
	}
}

function checkVictory() {
	$_POST["result"] = "c";
	$times = 0;
	//set the time I have click the TRY button.
	if (isset($_COOKIE["time"]) == FALSE) {
		setcookie("time", 0, time() + 3600 * 24);
	}
	else {
		$times = $_COOKIE['time'];
	}
	//check if there is the POST 'choose' that could be 'Try' or 'Restart'
	//check also if the LEVEL is selected
	if (isset($_POST["numberTyped"]) && is_numeric($_POST["numberTyped"]) && isset($_POST["choose"]) && isset($_POST["level"]) && $_POST["choose"] == "Try") {
		
		//these are some conditions that check if the player can play another time
		if ($_POST["level"] == 'Easy' && ($times+1) < 10) {
			print "<h3>You have tried for " . ($times + 1) . " times (max 10)</h3>";
			numberTyped();
		} else if ($_POST["level"] == 'Medium' && ($times+1) < 7) {
			print "<h3>You have tried for " . ($times + 1) . " times (max 7)</h3>";
			numberTyped();
		} else if ($_POST["level"] == 'Hard' && ($times+1) < 5) {
			print "<h3>You have tried for " . ($times + 1) . " times(max 5)</h3>";
			numberTyped();
		} else if (isset($_POST["level"]) == FALSE) {
			print "<h1>You must choose a level!</h1>";
		} else {
			$_POST["result"] = "g";
			//g is GAME OVER that disables the TRY button
			print "<h1>Game over! Click on restart!</h1>";
		}
	} else if (isset($_POST["choose"]) && $_POST["choose"] == 'Restart') {
		restart();
	} else {
		print "<h2 style='color:red'>Choose the difficult level!</h2>";
		print "<h3>If you have choosed it, restart!<h3>";
	}
}

function numberTyped() {
	$numberGuessed = 0;
	$times = 0;
	//set the time I have click the TRY button.
	if (isset($_COOKIE["time"]) == FALSE) {
		setcookie("time", 0, time() + 3600 * 24);
	}
	else {
		$times = $_COOKIE['time'];
	}
	if ($times == 0) {
		setcookie("level", $_POST['level'], time() + 3600 * 24);
	}
	if (isset($_COOKIE["guessNumber"]) == FALSE) {
		guessFirstNumber();
		$numberGuessed = $_POST["guessNumber"];
	} else {
		$numberGuessed = $_COOKIE["guessNumber"];
	}
	//random number choosed by the system
	$numberTyped = $_POST["numberTyped"];
	//number typed by the user
	setCookie('numbers[' . ($times) . ']', $numberTyped, time() + 3600 * 24);
	if ($numberTyped == $numberGuessed) {
		print "<h1 style='font-size:30px'>Numbers typed:</h1><br>";
		printCookies();
		echo "Last number typed (time,number)-> $times : $numberTyped <br />\n";
		print "<h1 style='font-size:100px;color:red'>You won!</h1>";
		$_POST["result"] = "w";
		//w is win that disables the TRY button
	} else {
		print "<h1 style='font-size:30px'>Numbers typed:</h1><br>";
		printCookies();
		echo "Last number typed -> $times : $numberTyped <br />\n";
		print "<h2>" . 'Wrong!Try another time!' . "<h2>";
	}
	$times += 1;
	setcookie("time", $times, time() + 3600 * 24);
}

function restart() {
	cleanCookies();
}

function cleanCookies() {
	if (isset($_COOKIE["time"])) {
		$times = $_COOKIE["time"];
		while ($times >= 0) {
			if ($times == 0) {
				setCookie('numbers[0]', "", time() - 3600 * 24);
				break;
			} else {
				setCookie('numbers[' . $times . ']', "", time() - 3600 * 24);
				$times--;
			}
		}
		$_POST['level'] = 'a';
		setcookie("time", "", time() - 3600 * 24);
		setcookie("guessNumber", "", time() - 3600 * 24);
		setcookie("level", "", time() - 3600 * 24);
	}

}

function printCookies() {
	if (isset($_COOKIE['numbers'])) {
		foreach ($_COOKIE['numbers'] as $name => $value) {
			$value = htmlspecialchars($value);
			$name = htmlspecialchars($name);
			echo "$name : $value <br />\n";
		}
	}
}
?>